from django.contrib import admin

# Register your models here.
from django.template.loader import get_template
