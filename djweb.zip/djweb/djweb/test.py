#!/usr/bin/env python3
# -*-coding:utf-8-*-
from __future__ import division

import os
import os

from django.template.loader import get_template


get_template('ho.html')
