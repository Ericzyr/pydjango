function attackEnemy() {
    document.write("land on");
    alert("ready go");
}

function displayDate(){
	document.getElementById("demo").innerHTML=Date();
}

