#!/usr/bin/env/python
# _*_coding:utf-8_*_

# v = {'key1':{'key2':'value'},}
# p ={'ley':'vlue'}
# dic={'key':v }






def family (argv):

    sum = 0
    for i in argv.values():
        sum = sum + i
    return sum





def famil (**args):

    print(args)

    for t in args.values():
        print(t)
        sum = 0
        for i in t.values():
            sum = sum + i
    print(sum)



famil(
    kt={
    '朝干（嗣子）': 5,
    'fg': 2
    },
    bt={
    'tw': 5,
    'fb': 2
    }
)



ar = {
        'a': {'b': 5},
        'aa': {'c': 5}
        }





# a = {'A':a,'B':'b'}



# 長門周南祖宗系 = {
#     '失諱(長）': family(
#         {
#             '失諱(長）':2,
#             '失諱（次）':1
#         }
#
#     ),
#
#     "灼（次）":  family(
#              {
#             '基茂(長）': famil(
#                 kt={
#                     '朝干（嗣子）':5
#                 }
#             )
#             }
#     )
#
# }
#
# 貳門召南祖宗系 ={
#     '失諱（長）': 1,
#     '失諱（次）': 2,
#     '燈（三）': 5,
#     '煊（四）': 5,
#     '勤（五）': 5
# }
#
# 叁門汝城祖宗系 = {
#     '失諱（長）': 1,
#     '燦（次）': 2,
#     '煜（三）': 2
# }
#
#
# 六世祖 = {'長門周南祖宗系': family(長門周南祖宗系), '貳門召南祖宗系':family(貳門召南祖宗系), '叁門汝城祖宗系': family(叁門汝城祖宗系), }
#
# # print(六世祖)
#
#
#
# 五世祖 = {'元良祖宗系': family(六世祖)}

# print(五世祖)


