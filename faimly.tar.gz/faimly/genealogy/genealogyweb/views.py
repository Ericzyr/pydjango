from django.shortcuts import render

import json
import collections

def login(request):
    return render(request,'login.html',locals())

def fimalyintro(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        id_number = request.POST.get('id_number')
        print(name)
    return render(request, 'fimalyintro.html', locals())


def fimalymain(request):

    def family(argv):
        sum = 0
        for i in argv.values():
            sum = sum + i
        return sum



# ============================================================================
# 长门 =================九世祖 從===============================

    zhaoxiang={}
    zhaoxiang=朝相=collections.OrderedDict()
    朝相['失諱（長）']=2
    朝相['希鳳（次）']=2
    朝相['失諱（三）']=2

    wu={}
    wu=无=collections.OrderedDict()
    无['']=1

    wu = {}
    wu = 无 = collections.OrderedDict()
    无[''] = 1

    hongbaosan={}
    hongbaosan=洪賓三=collections.OrderedDict()
    洪賓三['從武']=1


    # ===========================================

    zhaogan={}
    zhaogan=朝斡嗣子=collections.OrderedDict()
    朝斡嗣子['希聖（長）']=2
    朝斡嗣子['從顏（次）']=2
    朝斡嗣子['從敏（三）']=2


    jhzs={}
    jhzs=基恒长孙=collections.OrderedDict()
    基恒长孙['失諱（長）']=2
    基恒长孙['失諱（次）']=2

    jhss={}
    jhss=基恒三孙 = collections.OrderedDict()
    基恒三孙['失諱（長）']=2
    基恒三孙['錫智（次）']=2



# =====================================================

    rmznzrz={}
    rmznzrz=rmznzrz失諱長=collections.OrderedDict()
    rmznzrz失諱長['希仁（長）']= 1
    rmznzrz失諱長['失諱（次）']= 2
    rmznzrz失諱長['希德（三）']= 2

    rmznzrc={}
    rmznzrc=rmznzrc失諱次=collections.OrderedDict()
    rmznzrc失諱次['失諱']= 1



    zhaoxuan={}
    zhaoxuan=朝選=collections.OrderedDict()
    朝選['從順（長）']=1
    朝選['從讓（次）']=1
    朝選['失諱（三）']=1


    zhaozheng={{}}
    zhaozheng=朝臻長=collections.OrderedDict()
    朝臻長['失諱']=2

    zhaohai = {{}}
    zhaohai = 朝海次 = collections.OrderedDict()
    朝海次['失諱'] = 2









































# ============================================================================
# 长门 =================八世祖 朝===============================
    bszjz ={}
    bszjz=bszjz失諱長=collections.OrderedDict()
    bszjz失諱長['朝相']=family(朝相)

    bszjc={}
    bszjc=bszjc失諱次=collections.OrderedDict()
    bszjc失諱次['失諱（長）'] = family(无)
    bszjc失諱次['失諱（次）'] = family(无)
    bszjc失諱次['洪賓（三）'] = family(洪賓三)


    jimao={}
    jimao=基茂=collections.OrderedDict()
    基茂['朝斡(嗣子)']=family(朝斡嗣子)



    jiheng={}
    jiheng=基恒=collections.OrderedDict()
    基恒['失諱（長）']= family(基恒长孙)
    基恒['朝斡（出嗣二門）']= 1
    基恒['失諱（三）']=family(基恒三孙)

# ============================================================================
# 二门 =================八世祖 朝===============================
    rmznzr={}
    rmznzr=rmznzr失諱長=collections.OrderedDict()
    rmznzr失諱長['失諱（長）']= family(rmznzrz失諱長)
    rmznzr失諱長['失諱（次）']= family(rmznzrc失諱次)

    rmznzc={}
    rmznzc=rmznzc失諱次=collections.OrderedDict()
    rmznzc失諱次['朝選']=family(朝選)

    zmznrz={}
    zmznrz=zmznrz失諱=collections.OrderedDict()
    zmznrz失諱['乏嗣'] = 1


    jishan={}
    jishan=基善長=collections.OrderedDict()
    基善長['朝臻（長）'] = family(朝臻長)
    基善長['朝海（次）'] = family(朝海次)
    基善長['朝元（三）'] = family(朝元三)

    dengsancc={}
    dengsancc=dengsancc失諱次=collections.OrderedDict()
    dengsancc失諱次['失諱']=2

    jikang={}
    jikang =基康=collections.OrderedDict()
    基康['朝范']=1


    jiyi={}
    jiyi=基凝長=collections.OrderedDict()
    基凝長['朝璽']=1

    jiduan={}
    jiduan=基端次=collections.OrderedDict()
    基端次['朝舉']=3


    jitian={}
    jitian=基田三=collections.OrderedDict()
    基田三['朝宗'] = 2


# =================================================
    smrczz={}
    smrczz=smrczz失諱長=collections.OrderedDict()
    smrczz失諱長['失諱']=3

    smrczc= {}
    smrczc = smrczc失諱次 = collections.OrderedDict()
    smrczc失諱次['失諱'] = 3

    smrczsan = {}
    smrczsan = smrczsan失諱三 = collections.OrderedDict()
    smrczsan失諱三 ['失諱'] = 3

    smrczsi = {}
    smrczsi = smrczsi失諱四 = collections.OrderedDict()
    smrczsi失諱四['朝彥'] = 3


    jitai={}
    jitai=基泰=collections.OrderedDict()
    基泰['朝貴（長）']=2
    基泰['朝獻（次）']=2

    jilong={}
    jilong=基隆長=collections.OrderedDict()
    基隆長['朝君(長)']= 2
    基隆長['朝清(次)']= 2

    jiyao={}
    jiyao=基耀次=collections.OrderedDict()
    基耀次['朝五']=2

    # ===================================================

    jiliang={}
    jiliang=基亮=collections.OrderedDict()
    基亮['朝臣'] = 1



#============================================================================
    # 长门 =================八世祖 基===============================
    zmznz ={}
    zmznz=zmznz失諱長=collections.OrderedDict()
    zmznz失諱長['失諱（長）'] = family(bszjz失諱長)
    zmznz失諱長['失諱（次）']= family(bszjc失諱次)

    zhuoci ={}
    zhuoci = 灼次 =collections.OrderedDict()
    灼次['基茂'] = family(基茂)


    zmznthree ={}
    zmznthree = 失諱三=collections.OrderedDict()
    失諱三['基恒']=family(基恒)



    # 二门 =================八世祖 基==============================
    rmznz = {}
    rmznz = rmznz失諱長 = collections.OrderedDict()
    rmznz失諱長['失諱（長）'] = family(rmznzr失諱長)
    rmznz失諱長['失諱（次）'] = family(rmznzc失諱次)

    rmznr = {}
    rmznr = rmznr失諱次 = collections.OrderedDict()
    rmznr失諱次['失諱'] = family(zmznrz失諱)


    dengsan = {}
    dengsan= 燈三=collections.OrderedDict()
    燈三['基善（長）'] = family(基善長)
    燈三['失諱（次）'] = family(dengsancc失諱次)

    xuansi = {}
    xuansi= 煊四=collections.OrderedDict()
    煊四['基康'] = family(基康)

    qinwu = {}
    qinwu= 勤五=collections.OrderedDict()
    勤五['基凝（長）'] = family(基凝長)
    勤五['基端（次）'] = family(基端次)
    勤五['基田（三）'] = family(基田三)

    #三门====================八世祖 基===================

    smrcz ={}
    smrcz=smrcz失諱長=collections.OrderedDict()
    smrcz失諱長['失諱（長）'] = family(smrczz失諱長)
    smrcz失諱長['失諱（次）'] = family(smrczc失諱次)
    smrcz失諱長['失諱（三）'] = family(smrczsan失諱三)
    smrcz失諱長['失諱（四）'] = family(smrczsi失諱四)

    canci={}
    canci=燦次=collections.OrderedDict()
    燦次['基泰']=family(基泰)

    yusan = {}
    yusan = 煜三 = collections.OrderedDict()
    煜三['基隆(長)'] = family(基隆長)
    煜三['基耀(次)'] = family(基耀次)

    # 旁支===================八世祖 基========================

    zhu={}
    zhu=渚=collections.OrderedDict()
    渚['基亮'] = family(基亮)



# ================================================================
    # ===========================七世祖===========================
    zmzn = {}
    zmzn = 長門周南祖宗系= collections.OrderedDict()
    長門周南祖宗系['失諱(長)'] = family(zmznz失諱長)
    長門周南祖宗系['灼(次)'] = family(灼次)
    長門周南祖宗系['失諱(三)'] = family(失諱三)


    rmzn = {}
    rmzn = 貳門召南祖宗系 = collections.OrderedDict()
    貳門召南祖宗系['失諱（長）'] = family(rmznz失諱長)
    貳門召南祖宗系['失諱（次）'] = family(rmznr失諱次)
    貳門召南祖宗系['燈（三）'] = family(燈三)
    貳門召南祖宗系['煊（四）'] = family(煊四)
    貳門召南祖宗系['勤（五）'] = family(勤五)


    smrc = {}
    smrc = 叁門汝城祖宗系 = collections.OrderedDict()
    叁門汝城祖宗系['失諱（長）'] = family(smrcz失諱長)
    叁門汝城祖宗系['燦（次）'] = family(燦次)
    叁門汝城祖宗系['煜（三）'] = family(煜三)

    pztnp = {}
    pztnp = 旁支太南祖宗系 = collections.OrderedDict()
    旁支太南祖宗系['渚'] = family(渚)

# ================================================================
    # ========================六世祖===========================
    six = {}
    six = 六世祖 = collections.OrderedDict()
    六世祖['長門周南祖宗系'] = family(長門周南祖宗系)
    六世祖['貳門召南祖宗系'] = family(貳門召南祖宗系)
    六世祖['叁門汝城祖宗系'] = family(叁門汝城祖宗系)

    pztn = {}
    pztn = 六世祖旁支太南祖宗系 = collections.OrderedDict()
    六世祖旁支太南祖宗系['旁支太南祖宗系'] = family(旁支太南祖宗系)



# ================================================================
    # =======================五世祖============================

    five = 五世祖 = {'元良祖宗系': family(六世祖)}




    return render(request,'fimalymain.html',locals())